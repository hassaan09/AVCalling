import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import "./App.css"

const SERVER_URL = 'http://localhost:8080'; // Update with your server URL
const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY3NTI5Njg1MDRmMjEzZWJmZDVmYjAyYyIsImVtYWlsIjoiYmV0YUBnbWFpbC5jb20iLCJ1c2VybmFtZSI6ImJldGEiLCJpYXQiOjE3MzQ2MTc0NjUsImV4cCI6MTczNDcwMzg2NX0.1mOvRhhan2IiyaXyuAVR-A06iLsP4f3tRr6ULYEdvd8'; // Replace with your actual token

const CallComponent = () => {
  const [socket, setSocket] = useState(null);
  const [receiverId, setReceiverId] = useState('');
  const [callType, setCallType] = useState('');
  const [incomingCall, setIncomingCall] = useState(null); // To store incoming call data
  const [callStatus, setCallStatus] = useState(''); // To track current call status

  useEffect(() => {
    // Create the socket connection
    const socketInstance = io(`${SERVER_URL}/im`, {
      query: { token },
    });

    setSocket(socketInstance);

    // Handle socket connection
    socketInstance.on('connect', () => {
      console.log('Connected to server');
    });

    // Handle incoming calls
    socketInstance.on('incomingCall', (callData) => {
      console.log(`Incoming call from ${callData.senderName} (${callData.callType})`);
      setIncomingCall(callData); // Store incoming call data
      setCallStatus('Incoming'); // Update call status to 'Incoming'
    });

    // Event listeners for call actions
    socketInstance.on('callAnswered', (data) => {
      console.log(`Call ${data.callId} answered`);
      setCallStatus('Answered');
    });

    // Handle the callRejected event using the method you mentioned
    socketInstance.on('callRejected', (callId) => {
      console.log(`Call ${callId} rejected`);
      setCallStatus('Rejected');
      setIncomingCall(null); // Clear incoming call data
    });

    socketInstance.on('callEnded', () => {
      console.log('The call has ended.');
      setCallStatus('Ended');
      setIncomingCall(null); // Reset incoming call when call ends
    });

    return () => {
      socketInstance.disconnect();
    };
  }, []);

  // Initiate the call
  const initiateCall = (type) => {
    if (socket) {
      socket.emit('initiateCall', { receiverId, callType: type });
      console.log(`Initiating ${type} call to ${receiverId}`);
      setCallStatus(`Calling ${receiverId}...`);
    }
  };

  // Handle answer call action
  const handleAnswerCall = () => {
    if (socket && incomingCall) {
      socket.emit('answerCall', { callId: incomingCall.callId });
      console.log(`Answering call from ${incomingCall.senderName}`);
      setCallStatus('Answered');
      setIncomingCall(null); // Clear incoming call data
    }
  };

  // Handle reject call action
  const handleRejectCall = () => {
    if (socket && incomingCall) {
      // Emit the reject call event with the correct callId
      socket.emit('rejectCall', { callId: incomingCall.callId });
      console.log(`Rejecting call from ${incomingCall.senderName}`);

      // Update status and clear incoming call data
      setCallStatus('Rejected');
      setIncomingCall(null);
    }
  };

  return (
    <div>
      <h2>Initiate a Call</h2>
      <input
        type="text"
        placeholder="Enter participant ID"
        value={receiverId}
        onChange={(e) => setReceiverId(e.target.value)}
      />
      <br />
      <button onClick={() => initiateCall('audio')}>Start Audio Call</button>
      <button onClick={() => initiateCall('video')}>Start Video Call</button>

      <hr />
      {callStatus && <h3>Status: {callStatus}</h3>}

      {/* Overlay for Incoming Call */}
      {incomingCall && callStatus === 'Incoming' && (
        <div style={overlayStyle}>
          <div style={overlayContentStyle}>
            <h3>Incoming call from {incomingCall.senderName} ({incomingCall.callType})</h3>
            <button onClick={handleAnswerCall} style={buttonStyle}>Answer</button>
            <button onClick={handleRejectCall} style={buttonStyle}>Reject</button>
          </div>
        </div>
      )}
    </div>
  );
};

// Inline styles for overlay
const overlayStyle = {
  position: 'fixed',
  top: -280,
  left: -259,
  width: '100%',
  height: '100%',
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  zIndex: 1000, // Make sure overlay is on top
};

const overlayContentStyle = {
  backgroundColor: '#fff',
  padding: '20px',
  borderRadius: '10px',
  textAlign: 'center',
  boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)',
  minWidth: '300px',
};

const buttonStyle = {
  margin: '10px',
  padding: '10px 20px',
  backgroundColor: '#007bff',
  color: '#fff',
  border: 'none',
  borderRadius: '5px',
  cursor: 'pointer',
};

export default CallComponent;

